# BMLD-Inf2-AppV0

Das leere Gerüst um eine App aufzubauen.
